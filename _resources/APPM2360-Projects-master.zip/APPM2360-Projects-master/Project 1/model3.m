function [ AcPrime ] = model3( t, Ac, r )
%model 3
AcPrime = r.*Ac;
end

