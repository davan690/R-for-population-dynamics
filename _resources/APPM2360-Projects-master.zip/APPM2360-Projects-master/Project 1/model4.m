function [ AcPrime ] = model4( Ac, P, r )

AcPrime = r.*Ac-P;

end

