function [Acprime] = model5 ( r, A, S)
Acprime = r*A + S
end