for(i=1:1:33)
    vert(i,1) = i;
end