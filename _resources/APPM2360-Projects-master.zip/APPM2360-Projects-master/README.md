APPM2360-Projects
=================

Code for APPM2360 Projects

Code for the three projects done in APPM2360 @ CU Boulder Fall 2014

This repository is poorly organized. You have been warned.
