%This code tells us how much the loan would grow if the interest
%compounded how ever many times a year with no payments being made
r = 0.03;
y0 = 750000;
t = 5;
n = [1,2,4,12];
for i = 1:4
    y = y0*((1+(r/n(i))).^n*t)
end

