p1 = 7234.30;
p2 = 4022.55; %These were the payments I calculated at Starbucks.  I didn't use the payment function for these

r1 = 0.03;
r2 = 0.05;

t = linspace(0,30,10000);
C1 = (750000*r1)-(12*p1);
C2 = (750000*r2)-(12*p2);

y1 = (C1*exp(r1*t)+12*p1)/(r1);
y2 = (C2*exp(r2*t)+12*p2)/(r2);



figure;
plot(t,y1);
hold on;
plot(t,y2);
ylim([0,750000]);
xlabel('Time (years)');
ylabel('Loan Balance ($)');
legend('10 year','30 year');
title('Time to pay off 10 year mortgage with 3% rate and 30 year with 5% rate','FontSize',13)
