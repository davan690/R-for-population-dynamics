y0 = 750000;
r1 = 0.03;
r2 = 0.05;
p1 = payment(y0,10,r1);
p2 = payment(y0,30,r2); %Using the payment function

Ap1 = p1*(12*10);
Ap2 = p2*(12*30); %This calculates the total amount payed including the cost of the house and interest

I1 = Ap1-y0;
I2 = Ap2-y0;%By taking the total paid minus the cost of the house we find the amount of total interest paied
