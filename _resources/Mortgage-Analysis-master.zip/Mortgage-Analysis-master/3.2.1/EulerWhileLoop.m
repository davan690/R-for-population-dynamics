function EulerWhileLoop(func,y0,h,t0,tf)

t = t0:h:tf;
c = 0:1:750000;
y(1)=y0;
i=1;

while(i<max(size(t)))
    y(i+1) = y(i) + h*(feval(func,t(i),y(i)));
    i = i+1;
end

plot(t,y,'LineWidth',1)
set(gca,'FontSize',12)
xlabel('t','FontSize',14)
ylabel('y(t)','FontSize',14)
axis([0 tf 0 750000])