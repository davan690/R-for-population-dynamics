clear all
clc

% Executes Euler on y_prime for h = 0.01
hold on
EulerWhileLoop(@y_prime,750000,0.01,0,33)

b=0:0.1:35;
a = 750000*exp(0.05*b)-12*4000/0.05*(exp(0.05*b)-1);
plot(b,a,'LineWidth',1)

fun = @ (b)exp(0.05*b)*750000-12*4000/0.05*(exp(0.05*b)-1);
x0 = [0 35];
tf = fzero(fun,x0)

xlabel('t (Time in years)','FontSize',14)
ylabel('y (Outstanding balance in $)','FontSize',14)
legend('h = 0.01','True Solution')
title('Numerical Solution y(t) with h = 0.01 vs True Solution','FontSize',15)
hold off