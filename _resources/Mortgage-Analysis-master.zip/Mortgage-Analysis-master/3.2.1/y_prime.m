function yp = funct(t,y)
yp = 0.05*y-48000;
end